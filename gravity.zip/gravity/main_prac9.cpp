//Semestre 2017 - 2
//************************************************************//
//************************************************************//
//************** Alumno (s): *********************************//
//*************											******//
//*************											******//
//************************************************************//
//************************************************************//

#include "texture.h"
#include "figuras.h"
#include "Camera.h"


//NEW//////////////////NEW//////////////////NEW//////////////////NEW////////////////
static GLuint Gravity_display_list;	//Display List for the Monito


int w = 500, h = 500;
int frame=0,time,timebase=0;
int deltaTime = 0;
char s[30];

CCamera objCamera;	//Create objet Camera

GLfloat g_lookupdown = 0.0f;    // Look Position In The Z-Axis (NEW) 


int font = (int)GLUT_BITMAP_HELVETICA_18;

GLfloat Diffuse[] = { 0.5f, 0.5f, 0.5f, 1.0f };				// Diffuse Light Values
GLfloat Specular[] = { 1.0, 1.0, 1.0, 1.0 };				// Specular Light Values
GLfloat Position[] = { 0.0f, 7.0f, -5.0f, 0.0f };			// Light Position
GLfloat Position2[] = { 0.0f, 0.0f, -5.0f, 1.0f };			// Light Position


CTexture textSkyboxUnica;
CTexture textSkyboxFrontal;
CTexture textSkyboxAtras;
CTexture textSkyboxIzquierda;
CTexture textSkyboxDerecha;
CTexture textSkyboxArriba;
CTexture textSkyboxAbajo;

CTexture textCasa;
CTexture textPoste;
CTexture textMueble1;	
CTexture textMueble2;	
CTexture textTabli;	
CTexture textPiedra;	
CTexture textEsca;
CTexture textPuerta1;
CTexture textPuerta2;
CTexture textOlmeca;
CTexture textDor;
CTexture textLam;
CTexture textVen;
CTexture textInter;
CTexture textOso;
CTexture textLib1;
CTexture textLib2;
CTexture textLet;
CTexture textTronco;
CTexture textCartel;

//END NEW//////////////////////////////////////////


CFiguras fig1;
CFiguras fig2;
CFiguras fig3;
CFiguras fig4;	
CFiguras fig5;	
CFiguras fig6;
CFiguras fig7;	
CFiguras fig8;
CFiguras fig9;
CFiguras fig10; 

void Gravity()
{


	

//////// Construccion de casa//////
////Escala 1mtr aproximadamente es igual a 10 unidades


////Techo de casa
glPushMatrix();
glTranslatef(0.0f, 19.25f, 5.0f);
fig3.prisma(0.1f, 30.0f, 50.0f, textCasa.GLindex);
glPopMatrix();
//Techo de tienda
glPushMatrix();
glTranslatef(25.0f, 19.25f, 0);
fig3.prisma(0.1f, 20.0f, 20.0f, textCasa.GLindex);
glPopMatrix();

////Techo inclnado de casa izquierdo
	glPushMatrix();
	glTranslatef(-7.5f, 32.1f, 7.5f);
	glRotatef(60, 0, 0, 1);
	fig3.prisma(0.1f, 30.0f, 55.0f, textTabli.GLindex);
	glPopMatrix();
	//Techo inclinado de casa derecho
	glPushMatrix();
	glTranslatef(7.5, 32.1f, 7.5f);
	glRotatef(-60, 0, 0, 1);
	fig3.prisma(0.1f, 30.0f, 55.0f, textTabli.GLindex);
	glPopMatrix();

	//postes que sobresalen de frente 
	glPushMatrix();
	glTranslatef(-11, 25.0f, 34.0f);
	glRotatef(60, 0, 0, 1);
	fig3.prisma(0.5f, 0.5f, 4.0f, textMueble2.GLindex);
	glPopMatrix();

	glPushMatrix();
	glTranslatef(-5.4, 35.0f, 34.0f);
	glRotatef(60, 0, 0, 1);
	fig3.prisma(0.5f, 0.5f, 4.0f, textMueble2.GLindex);
	glPopMatrix();

	glPushMatrix();
	glTranslatef(-0.5, 43.0f, 34.0f);
	glRotatef(60, 0, 0, 1);
	fig3.prisma(0.5f, 0.5f, 4.0f, textMueble2.GLindex);
	glPopMatrix();
	//Izquierdo
	glPushMatrix();
	glTranslatef(5.4, 35.0f, 34.0f);
	glRotatef(-60, 0, 0, 1);
	fig3.prisma(0.5f, 0.5f, 4.0f, textMueble2.GLindex);
	glPopMatrix();

	//Postes de la base de madera
	//Derechos
	//1
	glPushMatrix();
	glTranslatef(14.5, 2, 39.5);
	fig3.prisma(4, 1.0f, 1.0f, textPoste.GLindex);
	glPopMatrix();
	//2
	glPushMatrix();
	glTranslatef(14.5f, 2, 29.5);
	fig3.prisma(4, 1, 1, textPoste.GLindex);
	glPopMatrix();
	//3
	glPushMatrix();
	glTranslatef(14.5f, 2, 19.5);
	fig3.prisma(4, 1, 1, textPoste.GLindex);
	glPopMatrix();
	//4
	glPushMatrix();
	glTranslatef(14.5f, 2, -19.5);
	fig3.prisma(4, 1, 1, textPoste.GLindex);
	glPopMatrix();

	//izquierdos
	//1
	glPushMatrix();
	glTranslatef(-14.5, 2, 39.5);
	fig3.prisma(4, 1.0f, 1.0f, textPoste.GLindex);
	glPopMatrix();
	//2
	glPushMatrix();
	glTranslatef(-14.5f, 2, 29.5);
	fig3.prisma(4, 1, 1, textPoste.GLindex);
	glPopMatrix();
	//3
	glPushMatrix();
	glTranslatef(-14.5f, 2, 19.5);
	fig3.prisma(4, 1, 1, textPoste.GLindex);
	glPopMatrix();
	//4
	glPushMatrix();
	glTranslatef(-14.5f, 2, 0);
	fig3.prisma(4, 1, 1, textPoste.GLindex);
	glPopMatrix();
	//5
	glPushMatrix();
	glTranslatef(-14.5f, 2, -19.5);
	fig3.prisma(4, 1, 1, textPoste.GLindex);
	glPopMatrix();

	// Base de madera
	glPushMatrix();
	glTranslatef(0, 4, 10);
	fig3.prisma(0.2f, 30.0f, 60.0f, textCasa.GLindex);
	glPopMatrix();


	//Pared derecha chica
	glPushMatrix();
	glTranslatef(14.9f, 11.7f, 20.0f);
	fig3.prisma(15.0f, 0.2f, 20.0f, textCasa.GLindex);
	glPopMatrix();
	//Pared Derecha chica 2
	glPushMatrix();
	glTranslatef(14.9f, 11.7f, -15.0f);
	fig3.prisma(15.0f, 0.2f, 10.0f, textCasa.GLindex);
	glPopMatrix();
	//pared izquierda larga
	glPushMatrix();
	glTranslatef(-14.9f, 11.7f, 5);
	fig3.prisma(15.0f, 0.2f, 50.0f, textCasa.GLindex);
	glPopMatrix();

	//Paredes Frontales 
	//Izquierda
	glPushMatrix();
	glTranslatef(-10.0f, 11.7f, 29.9f);
	fig3.prisma(15.0f, 10.0f, 0.2f, textCasa.GLindex);
	glPopMatrix();
	//Derecha
	glPushMatrix();
	glTranslatef(10.0f, 11.7f, 29.9f);
	fig3.prisma(15.0f, 10.0f, 0.2f, textCasa.GLindex);
	glPopMatrix();
	//Pared trasera
	glPushMatrix();
	glTranslatef(0.0f, 11.7f, -19.9f);
	fig3.prisma(15.0f, 30.0f, 0.2f, textCasa.GLindex);
	glPopMatrix();
	//Escalon bajo
	glPushMatrix();
	glTranslatef(0.0f, 1, 44.0f);
	fig3.prisma(2, 10, 4.0f, textEsca.GLindex);
	glPopMatrix();
	//Escalon alto
	glPushMatrix();
	glTranslatef(0.0f, 3.0f, 42.0f);
	fig3.prisma(2.0f, 10, 4.0f, textEsca.GLindex);
	glPopMatrix();
	
	////Entrada///                       ///Entrada
	glPushMatrix();
	glTranslatef(5.0f, 4.2f, 31.0f);
	fig9.cilindro(1.0f, 15, 20.0f, textMueble2.GLindex);
	glPopMatrix();

	glPushMatrix();
	glTranslatef(-5.0f, 4.2f, 31.0f);
	fig9.cilindro(1.0f, 15, 20.0f, textMueble2.GLindex);
	glPopMatrix();

	glPushMatrix();
	glTranslatef(7.5f, 19.2f, 31.0f);
	glRotatef(90, 0, 0, 1);
	fig9.cilindro(1.0f, 15, 20.0f, textMueble2.GLindex);
	glPopMatrix();

	/////////Soportes de casa Techo///////
	//Izquierdo
	glPushMatrix();
	glTranslatef(-14.3, 18.7, 5);
	fig3.prisma(1.0f, 1.0f, 49.6f, textPoste.GLindex);
	glPopMatrix();
	//derecho
	glPushMatrix();
	glTranslatef(14.3, 18.7, 5);
	fig3.prisma(1.0f, 1.0f, 49.6f, textPoste.GLindex);
	glPopMatrix();
	//Centro largo
	glPushMatrix();
	glTranslatef(0, 18.7, 5);
	fig3.prisma(1.0f, 1.0f, 49.6f, textPoste.GLindex);
	glPopMatrix();
	//centro corto
	glPushMatrix();
	glTranslatef(0, 18.7, 5);
	fig3.prisma(1.0f, 27.6f, 1.0f, textPoste.GLindex);
	glPopMatrix();
	//Frente
	glPushMatrix();
	glTranslatef(0, 18.7, 29.3);
	fig3.prisma(1.0f, 27.6f, 1.0f, textPoste.GLindex);
	glPopMatrix();
	//trasero
	glPushMatrix();
	glTranslatef(0, 18.7, -19.3);
	fig3.prisma(1.0f, 27.6f, 1.0f, textPoste.GLindex);
	glPopMatrix();

	/////////Postes de soporte casa ///////

	//Frente derecho
	glPushMatrix();
	glTranslatef(14.3, 11.2f, 29.3);
	fig3.prisma(14.0f, 1, 1.0f, textPoste.GLindex);
	glPopMatrix();
	//Frente izquierdo
	glPushMatrix();
	glTranslatef(-14.3, 11.2f, 29.3);
	fig3.prisma(14.0f, 1, 1.0f, textPoste.GLindex);
	glPopMatrix();
	//trasero derecho
	glPushMatrix();
	glTranslatef(14.3, 11.2f, -19.3);
	fig3.prisma(14.0f, 1, 1.0f, textPoste.GLindex);
	glPopMatrix();
	//trasero izquierdo
	glPushMatrix();
	glTranslatef(-14.3, 11.2f, -19.3);
	fig3.prisma(14.0f, 1, 1.0f, textPoste.GLindex);
	glPopMatrix();
	//central derecha
	glPushMatrix();
	glTranslatef(14.3, 11.2f, 10.5);
	fig3.prisma(14.0f, 1, 1.0f, textPoste.GLindex);
	glPopMatrix();
	//central izquierda
	glPushMatrix();
	glTranslatef(-14.3, 11.2f, 10.5);
	fig3.prisma(14.0f, 1, 1.0f, textPoste.GLindex);
	glPopMatrix();

	/////Postes inclinados casa////
	//Frente 1 izquierdo                                ////Inclinados
	glPushMatrix();
	glTranslatef(-13, 17.0f, 29.55);
	glRotatef(45, 0, 0, 1);
	fig3.prisma(0.5f, 5, 0.5f, textPoste.GLindex);
	glPopMatrix();
	//Frente 1 izqiuerdo
	glPushMatrix();
	glTranslatef(-14.45, 17.0f, 28);
	glRotatef(45, 1, 0, 0);
	fig3.prisma(0.5f, 0.5, 5, textPoste.GLindex);
	glPopMatrix();
	//Frente 2 derecho                                ////Inclinados
	glPushMatrix();
	glTranslatef(13, 17.0f, 29.55);
	glRotatef(-45, 0, 0, 1);
	fig3.prisma(0.5f, 5, 0.5f, textPoste.GLindex);
	glPopMatrix();
	//Frente 2 izquierdo                                ////Inclinados
	glPushMatrix();
	glTranslatef(14.45, 17.0f, 28);
	glRotatef(45, 1, 0, 0);
	fig3.prisma(0.5f, 0.5, 5, textPoste.GLindex);
	glPopMatrix();
	//trasero 1 derecho                                ////Inclinados
	glPushMatrix();
	glTranslatef(13, 17.0f, -19.55);
	glRotatef(-45, 0, 0, 1);
	fig3.prisma(0.5f, 5, 0.5f, textPoste.GLindex);
	glPopMatrix();
	//trasero 2 derecho                               ////Inclinados
	glPushMatrix();
	glTranslatef(14.45, 17.0f, -18);
	glRotatef(-45, 1, 0, 0);
	fig3.prisma(0.5f, 0.5, 5, textPoste.GLindex);
	glPopMatrix();
	//Frente 2 izquierdo                              ////Inclinados
	glPushMatrix();
	glTranslatef(-13, 17.0f, -19.55);
	glRotatef(45, 0, 0, 1);
	fig3.prisma(0.5f, 5, 0.5f, textPoste.GLindex);
	glPopMatrix();
	//trasero 2 izquierdo                                ////Inclinados
	glPushMatrix();
	glTranslatef(-14.45, 17.0f, -18.0);
	glRotatef(-45, 1, 0, 0);
	fig3.prisma(0.5f, 0.5, 5, textPoste.GLindex);
	glPopMatrix();
	//Central 1 izquierdo                              ////Inclinados
	glPushMatrix();
	glTranslatef(-14.45, 17.0f, 8.80);
	glRotatef(45, 1, 0, 0);
	fig3.prisma(0.5f, 0.5, 5, textPoste.GLindex);
	glPopMatrix();
	//central 2 izquierdo                                ////Inclinados
	glPushMatrix();
	glTranslatef(-14.45, 17.0f, 12.15);
	glRotatef(-45, 1, 0, 0);
	fig3.prisma(0.5f, 0.5, 5, textPoste.GLindex);
	glPopMatrix();
	//Central 1 derecho                              ////Inclinados
	glPushMatrix();
	glTranslatef(14.45, 17.0f, 8.80);
	glRotatef(45, 1, 0, 0);
	fig3.prisma(0.5f, 0.5, 5, textPoste.GLindex);
	glPopMatrix();
	//central 2 derecho                                ////Inclinados
	glPushMatrix();
	glTranslatef(14.45, 17.0f, 12.15);
	glRotatef(-45, 1, 0, 0);
	fig3.prisma(0.5f, 0.5, 5, textPoste.GLindex);
	glPopMatrix();

	//puerta//
	glPushMatrix();
	glTranslatef(-2.45f, 11.15f, 30.0f);
	fig3.prisma(13.6f, 4.75, 0.1f, textPuerta1.GLindex);
	glPopMatrix();

	glPushMatrix();
	glTranslatef(2.45f, 11.15f, 30.0f);
	fig3.prisma(13.6f, 4.75, 0.1f, textPuerta1.GLindex);
	glPopMatrix();


	////Tienda////                ///Tienda///             ////tienda///

	////Techo inclnado de tienda izquierdo
	glPushMatrix();
	glTranslatef(22.5f, 23.4f, 5.0f);
	glRotatef(40, 1, 0, 0);
	fig3.prisma(0.1f, 25.0f, 13.0f, textTabli.GLindex);
	glPopMatrix();
	//Techo inclinado de tienda derecho
	glPushMatrix();
	glTranslatef(22.5, 23.4f, -5.0f);
	glRotatef(-40, 1, 0, 0);
	fig3.prisma(0.1f, 25.0f, 13.0f, textTabli.GLindex);
	glPopMatrix();
	/////////////////////////////////////////////////////////////////////////////////////////////////
	glBindTexture(GL_TEXTURE_2D, textCasa.GLindex);   // choose the texture to use.
	glPushMatrix();

	glTranslatef(35, 19.2, 0);
	glBegin(GL_POLYGON);
	glTexCoord2f(0.0f, 0.0f); glVertex3f(0, 0, -10);
	glTexCoord2f(0.5f, 1.0f); glVertex3f(0, 8.4, 0);
	glTexCoord2f(1.0f, 0.0f); glVertex3f(0, 0, 10);
	glEnd();
	glPopMatrix();
	////////////////////////////////////////////////////////////////////////////////////////////////////////

	//Base de madera de tienda
	glPushMatrix();
	glTranslatef(27.5f, 4, 0.0);
	fig3.prisma(0.2f, 25.0f, 20.0f, textCasa.GLindex);
	glPopMatrix();
	//pared izquierda tienda
	glPushMatrix();
	glTranslatef(25.0f, 11.7f, 9.9f);
	fig3.prisma(15, 20.0f, 0.2f, textCasa.GLindex);
	glPopMatrix();
	//pared derecha tienda
	glPushMatrix();
	glTranslatef(25.0f, 11.7f, -9.9f);
	fig3.prisma(15, 20.0f, 0.2f, textCasa.GLindex);
	glPopMatrix();

	//Paredes de puerta 
	glPushMatrix();
	glTranslatef(34.9, 11.7, 7.5);
	fig3.prisma(15.0f, 0.2f, 5.0f, textCasa.GLindex);
	glPopMatrix();
	//Paredes de puerta 
	glPushMatrix();
	glTranslatef(34.9, 11.7, -7.5);
	fig3.prisma(15.0f, 0.2f, 5.0f, textCasa.GLindex);
	glPopMatrix();
	//Pared de puerta arriba
	glPushMatrix();
	glTranslatef(34.9, 18.2, 0);
	fig3.prisma(2.0f, 0.2f, 10.0f, textCasa.GLindex);
	glPopMatrix();

	//Escalon bajo piedra
	glPushMatrix();
	glTranslatef(28.5f, 1, 0.0f);
	fig3.prisma(2, 30, 20.0f, textPiedra.GLindex);
	glPopMatrix();
	//Escalon alto piedra
	glPushMatrix();
	glTranslatef(27.5f, 3, 0);
	fig3.prisma(2.0f, 28, 20.0f, textPiedra.GLindex);
	glPopMatrix();

	//P�ste derecho libre
	glPushMatrix();
	glTranslatef(38.5, 10.7f, 9);
	fig3.prisma(13.0f, 1, 1.0f, textPoste.GLindex);
	glPopMatrix();
	//poste izquierdo libre
	glPushMatrix();
	glTranslatef(38.5, 10.7f, -9);
	fig3.prisma(13.0f, 1, 1, textPoste.GLindex);
	glPopMatrix();

	//techumbre tienda//              ///Techumbre tienda//
	glPushMatrix();
	glTranslatef(37.2, 18.0f, 0);
	glRotatef(-30, 0, 0, 1);
	fig3.prisma(0.2f, 5, 20, textLam.GLindex);
	glPopMatrix();

	////Puerta de sotano////
	//Derecha
	glPushMatrix();
	glTranslatef(25.0f, 2.5f, 14.7);
	glRotatef(35, 1, 0, 0);
	fig3.prisma(0.2f, 5.0f, 10.0f, textMueble2.GLindex);
	glPopMatrix();
	//izquierda
	glPushMatrix();
	glTranslatef(30.1f, 2.5f, 14.7);
	glRotatef(35, 1, 0, 0);
	fig3.prisma(0.2f, 5.0f, 10.0f, textMueble2.GLindex);
	glPopMatrix();

	//////////////////////////////////////
	glBindTexture(GL_TEXTURE_2D, textCasa.GLindex);   // choose the texture to use.
	glPushMatrix();
	glTranslatef(0, 19.2, 30);
	glBegin(GL_POLYGON);
	glTexCoord2f(0.0f, 0.0f); glVertex3f(-15, 0, 0);
	glTexCoord2f(0.5f, 1.0f); glVertex3f(0, 26, 0);
	glTexCoord2f(1.0f, 0.0f); glVertex3f(15, 0, 0);
	glEnd();
	glPopMatrix();

	glBindTexture(GL_TEXTURE_2D, textCasa.GLindex);   // choose the texture to use.
	glPushMatrix();
	glTranslatef(0, 19.2, -20);
	glBegin(GL_POLYGON);
	glTexCoord2f(0.2f, 0.0f); glVertex3f(15, 0, 0);
	glTexCoord2f(0.5f, 1.0f); glVertex3f(0, 26, 0);
	glTexCoord2f(0.8f, 0.0f); glVertex3f(-15, 0, 0);
	glEnd();
	glPopMatrix();
	//////////////////////////////////////////

	/////P�stes soporte tienda///
	// 1
	glPushMatrix();
	glTranslatef(24.5, 11.2f, -8.8);
	fig3.prisma(14.0f, 1, 1.0f, textPoste.GLindex);
	glPopMatrix();
	//2
	glPushMatrix();
	glTranslatef(24.5, 11.2f, 8.8);
	fig3.prisma(14.0f, 1, 1.0f, textPoste.GLindex);
	glPopMatrix();
	//orilla derecha
	glPushMatrix();
	glTranslatef(34, 11.2f, -9.3);
	fig3.prisma(14.0f, 1, 1.0f, textPoste.GLindex);
	glPopMatrix();
	//orilla izquierda
	glPushMatrix();
	glTranslatef(34, 11.2f, 9.3);
	fig3.prisma(14.0f, 1, 1.0f, textPoste.GLindex);
	glPopMatrix();


	//Postes soporte techo tienda
	//largo1
	glPushMatrix();
	glTranslatef(24.7, 18.7f, -9.3);
	fig3.prisma(1.0f, 19.8, 1.0f, textPoste.GLindex);
	glPopMatrix();
	//largo2
	glPushMatrix();
	glTranslatef(24.7, 18.7f, 9.3);
	fig3.prisma(1.0f, 19.8, 1.0f, textPoste.GLindex);
	glPopMatrix();
	//largo3
	glPushMatrix();
	glTranslatef(24.7, 18.7f, 0);
	fig3.prisma(1.0f, 19.8, 1.0f, textPoste.GLindex);
	glPopMatrix();
	//Central 1
	glPushMatrix();
	glTranslatef(24.3, 18.7f, 0);
	fig3.prisma(1.0f, 1, 17.6f, textPoste.GLindex);
	glPopMatrix();
	//Central 2
	glPushMatrix();
	glTranslatef(34.3, 18.7f, 0);
	fig3.prisma(1.0f, 1, 17.6f, textPoste.GLindex);
	glPopMatrix();

	///////Postes inclinados tienda////
	//trasero derecho                                ////Inclinados
	glPushMatrix();
	glTranslatef(34.2, 17.0f, -7.5);
	glRotatef(-45, 1, 0, 0);
	fig3.prisma(0.5f, 0.5, 5, textPoste.GLindex);
	glPopMatrix();
	//trasero izquierda                                ////Inclinados
	glPushMatrix();
	glTranslatef(34.2, 17.0f, 7.5);
	glRotatef(45, 1, 0, 0);
	fig3.prisma(0.5f, 0.5, 5, textPoste.GLindex);
	glPopMatrix();
	//trasero 2 derecho                               ////Inclinados
	glPushMatrix();
	glTranslatef(32.45, 17.0f, -9.55);
	glRotatef(-45, 0, 0, 1);
	fig3.prisma(0.5f, 5, 0.5, textPoste.GLindex);
	glPopMatrix();
	//trasero 2 izquierda                                ////Inclinados
	glPushMatrix();
	glTranslatef(32.45, 17.0f, 9.55);
	glRotatef(-45, 0, 0, 1);
	fig3.prisma(0.5f, 5, 0.5, textPoste.GLindex);
	glPopMatrix();


	//Centro 1 derecho
	glPushMatrix();
	glTranslatef(24.5, 17.0f, -7.55);
	glRotatef(-45, 1, 0, 0);
	fig3.prisma(0.5f, 0.5, 5, textPoste.GLindex);
	glPopMatrix();
	//Centro 2 derecho
	glPushMatrix();
	glTranslatef(26.2, 17.0f, -9.55);
	glRotatef(45, 0, 0, 1);
	fig3.prisma(0.5f, 5, 0.5, textPoste.GLindex);
	glPopMatrix();
	//Centro 3 derecho
	glPushMatrix();
	glTranslatef(22.8, 17.0f, -9.55);
	glRotatef(-45, 0, 0, 1);
	fig3.prisma(0.5f, 5, 0.5, textPoste.GLindex);
	glPopMatrix();
	//centro 1 izquierda                                ////Inclinados
	glPushMatrix();
	glTranslatef(24.5, 17.0f, 7.5);
	glRotatef(45, 1, 0, 0);
	fig3.prisma(0.5f, 0.5, 5, textPoste.GLindex);
	glPopMatrix();
	//centro 2 izquierda                                ////Inclinados
	glPushMatrix();
	glTranslatef(26.2, 17.0f, 9.55);
	glRotatef(45, 0, 0, 1);
	fig3.prisma(0.5f, 5, 0.5, textPoste.GLindex);
	glPopMatrix();
	//centro 3 izquierda                                ////Inclinados
	glPushMatrix();
	glTranslatef(22.8, 17.0f, 9.55);
	glRotatef(-45, 0, 0, 1);
	fig3.prisma(0.5f, 5, 0.5, textPoste.GLindex);
	glPopMatrix();

	//Puerta de tienda///
	glPushMatrix();
	glTranslatef(34.9f, 11.15f, 2.51);
	fig3.prisma(13.6f, 0.1f, 4.9f, textPuerta1.GLindex);
	glPopMatrix();

	glPushMatrix();
	glTranslatef(34.9f, 11.15f, -2.51);
	fig3.prisma(13.6f, 0.1, 4.9f, textPuerta1.GLindex);
	glPopMatrix();

	
	///////////////////////////////////////Planos////////////////////////////////////////////
	glPushMatrix();
	glEnable(GL_ALPHA_TEST);
	glAlphaFunc(GL_GREATER, 0.1f);
	glBindTexture(GL_TEXTURE_2D, textOlmeca.GLindex);   // choose the texture to use.
	
	glTranslatef(-7.7, 7.2, 8);
	glRotated(180, 0, 0, 1);
	glBegin(GL_POLYGON);
	glTexCoord2f(0.0f, 0.0f); glVertex3f(0,2,-2);
	glTexCoord2f(0.0f, 1.0f); glVertex3f(0,-2,-2);
	glTexCoord2f(1.0f, 1.0f); glVertex3f(0,-2,2);
	glTexCoord2f(1.0f, 0.0f); glVertex3f(0,2,2);
	glEnd();
	glDisable(GL_ALPHA_TEST);
	glPopMatrix();


	/////////////////let///////////
	glPushMatrix();
	glEnable(GL_ALPHA_TEST);
	glAlphaFunc(GL_GREATER, 0.1f);
	glBindTexture(GL_TEXTURE_2D, textLet.GLindex);   // choose the texture to use.

	glTranslatef(-13.5, 13, 25);
	glRotated(180, 1, 0, 0);
	glBegin(GL_POLYGON);
	glTexCoord2f(0.0f, 0.0f); glVertex3f(0, 2, -2);
	glTexCoord2f(0.0f, 1.0f); glVertex3f(0, -2, -2);
	glTexCoord2f(1.0f, 1.0f); glVertex3f(0, -2, 2);
	glTexCoord2f(1.0f, 0.0f); glVertex3f(0, 2, 2);
	glEnd();
	glDisable(GL_ALPHA_TEST);
	glPopMatrix();

	/////////////////Cartel///////////
	glPushMatrix();
	glEnable(GL_ALPHA_TEST);
	glAlphaFunc(GL_GREATER, 0.1f);
	glBindTexture(GL_TEXTURE_2D, textCartel.GLindex);   // choose the texture to use.

	glTranslatef(5, 37.5, 8);
	glRotated(180, 1, 0, 0);
	glBegin(GL_POLYGON);
	glTexCoord2f(0.0f, 0.0f); glVertex3f(0, 25, -25);
	glTexCoord2f(0.0f, 1.0f); glVertex3f(0, -25, -25);
	glTexCoord2f(1.0f, 1.0f); glVertex3f(0, -25, 25);
	glTexCoord2f(1.0f, 0.0f); glVertex3f(0, 25, 25);
	glEnd();
	glDisable(GL_ALPHA_TEST);
	glPopMatrix();


	

	//////////////////Ventanas///////////
	glPushMatrix();
	glTranslatef(0.0f, 14, -19.9);
	fig3.prisma(6, 6, 0.4, textVen.GLindex);
	glPopMatrix();

	glPushMatrix();
	glTranslatef(28.5f, 14, -10.);
	fig3.prisma(6, 6, 0.45, textVen.GLindex);
	glPopMatrix();

	glPushMatrix();
	glTranslatef(28.5f, 14, 10);
	fig3.prisma(6, 6, 0.45, textVen.GLindex);
	glPopMatrix();

	glPushMatrix();
	glTranslatef(0.0f, 30, 30);
	fig3.prisma(6, 6, 0.4, textVen.GLindex);
	glPopMatrix();

	glPushMatrix();
	glTranslatef(14.9f, 14, 20);
	fig3.prisma(6, 0.4, 6, textVen.GLindex);
	glPopMatrix();

	glPushMatrix();
	glTranslatef(-14.9f, 14, -10);
	fig3.prisma(6, 0.4, 6, textVen.GLindex);
	glPopMatrix();

	glPushMatrix();
	glTranslatef(-14.9f, 14, 20);
	fig3.prisma(6, 0.4, 6, textVen.GLindex);
	glPopMatrix();


	/////////////////////////////////////////////////Muebles////////////////////////////////////////////////////
	////Mostrador///////////////////////////////////
	glPushMatrix();
	glTranslatef(-10.0f, 4.3, 8);
	fig3.prisma(0.2, 6, 15, textMueble1.GLindex);
	glPopMatrix();

	glPushMatrix();
	glTranslatef(-12.9, 7.2, 8);
	fig3.prisma(5.5, 0.2, 15, textMueble1.GLindex);
	glPopMatrix();

	glPushMatrix();
	glTranslatef(-10, 10, 8);
	fig3.prisma(0.2, 6.4, 16, textMueble1.GLindex);
	glPopMatrix();

	glPushMatrix();
	glTranslatef(-10.3, 7.15, 15.4);
	fig3.prisma(5.7, 5.4, 0.2, textMueble1.GLindex);
	glPopMatrix();
	////////
	glPushMatrix();
	glTranslatef(-10.3, 7.15, 10.4);
	fig3.prisma(5.7, 5.4, 0.2, textMueble1.GLindex);
	glPopMatrix();
	///////
	glPushMatrix();
	glTranslatef(-10.3, 7.15, 5.4);
	fig3.prisma(5.7, 5.4, 0.2, textMueble1.GLindex);
	glPopMatrix();
	///////
	glPushMatrix();
	glTranslatef(-10.3, 7.15, 0.6);
	fig3.prisma(5.7, 5.4, 0.2, textMueble1.GLindex);
	glPopMatrix();

	/////////////////////////////////////////
	///////Mueble Peque�o//////////
	glPushMatrix();
	glTranslatef(-10.3, 4.3, -5);
	fig3.prisma(0.2, 5, 8, textMueble2.GLindex);
	glPopMatrix();

	glPushMatrix();
	glTranslatef(-10.3, 9.3, -5);
	fig3.prisma(0.2, 5, 8, textMueble2.GLindex);
	glPopMatrix();

	glPushMatrix();
	glTranslatef(-12.8, 6.9, -5);
	fig3.prisma(5, 0.2, 8, textMueble2.GLindex);
	glPopMatrix();

	glPushMatrix();
	glTranslatef(-10.3, 6.8, -1.1);
	fig3.prisma(4.8, 5, 0.2, textMueble2.GLindex);
	glPopMatrix();
	////////
	glPushMatrix();
	glTranslatef(-10.3, 6.8, -8.9);
	fig3.prisma(4.8, 5, 0.2, textMueble2.GLindex);
	glPopMatrix();
	///////////Puertitas de mueble///////
	glPushMatrix();
	glTranslatef(-7.9, 6.8, -7);
	fig3.prisma(4.8, 0.2, 3.7, textMueble2.GLindex);
	glPopMatrix();

	glPushMatrix();
	glTranslatef(-7.9, 6.8, -3.1);
	fig3.prisma(4.8, 0.2, 3.8, textMueble2.GLindex);
	glPopMatrix();


	////////////////////////////////////Refri de helado//////////////////////
	glPushMatrix();
	glTranslatef(-10, 4.7, 23);
	fig3.prisma(8, 5, 10, textPuerta2.GLindex);
	glPopMatrix();

	glPushMatrix();
	glEnable(GL_ALPHA_TEST);
	glAlphaFunc(GL_GREATER, 0.1f);
	glBindTexture(GL_TEXTURE_2D, textInter.GLindex);   // choose the texture to use.

	glTranslatef(-7.4, 6.4, 23);
	glRotated(180, 1, 0, 0);
	glBegin(GL_POLYGON);
	glTexCoord2f(0.0f, 0.0f); glVertex3f(0, 2, 2);
	glTexCoord2f(0.0f, 1.0f); glVertex3f(0, -2, 2);
	glTexCoord2f(1.0f, 1.0f); glVertex3f(0, -2, -2);
	glTexCoord2f(1.0f, 0.0f); glVertex3f(0, 2, -2);
	glEnd();
	glDisable(GL_ALPHA_TEST);
	glPopMatrix();
	//////////////////////////////Casco de buzo//////////
	glPushMatrix();
	glTranslatef(-10.3, 11, -5);
	fig6.esfera(2, 15, 15, textDor.GLindex);
	glPopMatrix();

	glPushMatrix();
	glTranslatef(-10.3, 9.5, -5);
	fig8.cono(1.5, 2.3, 15, textDor.GLindex);
	glPopMatrix();

	glPushMatrix();
	glTranslatef(-10.4, 11.2, -3.3);
	glRotatef(90, 1, 0, 0);
	fig9.cilindro(0.5, 0.4, 10, textDor.GLindex);
	glPopMatrix();
	//////////////
	glPushMatrix();
	glTranslatef(-10.4, 11.2, -7.1);
	glRotatef(90, 1, 0, 0);
	fig9.cilindro(0.5, 0.4, 10, textDor.GLindex);
	glPopMatrix();
	//////////////
	glPushMatrix();
	glTranslatef(-8, 11.1, -5);
	glRotatef(90, 0, 0, 1);
	fig9.cilindro(1.1, 0.4, 50, textDor.GLindex);
	glPopMatrix();
}



GLuint createDL() 
{
	GLuint GravityDL;
	

	// Create the id for the list
	GravityDL = glGenLists(1);
	// start list
	glNewList(GravityDL,GL_COMPILE);
	// call the function that contains 
	// the rendering commands
		Gravity();

	// endList
	glEndList();

	return(GravityDL);
}
			
void InitGL ( GLvoid )     // Inicializamos parametros
{
	glClearColor(0.0f, 0.0f, 0.0f, 0.0f);				// Negro de fondo	

	glEnable(GL_TEXTURE_2D);

	glShadeModel (GL_SMOOTH);
	//Para construir la figura comentar esto
	glLightfv(GL_LIGHT1, GL_POSITION, Position);
	glLightfv(GL_LIGHT1, GL_DIFFUSE, Diffuse);
	glEnable(GL_LIGHTING);
	glEnable(GL_LIGHT0);

	glEnable ( GL_COLOR_MATERIAL );

	glClearDepth(1.0f);									// Configuramos Depth Buffer
	glEnable(GL_DEPTH_TEST);							// Habilitamos Depth Testing
	glDepthFunc(GL_LEQUAL);								// Tipo de Depth Testing a realizar
	glHint(GL_PERSPECTIVE_CORRECTION_HINT, GL_NICEST);

	glEnable(GL_AUTO_NORMAL);
	glEnable(GL_NORMALIZE);
    

	textSkyboxFrontal.LoadTGA("mp_organic/organic_ft.tga");
	textSkyboxFrontal.BuildGLTexture();
	textSkyboxFrontal.ReleaseImage();

	textSkyboxAtras.LoadTGA("mp_organic/organic_bk.tga");
	textSkyboxAtras.BuildGLTexture();
	textSkyboxAtras.ReleaseImage();

	textSkyboxIzquierda.LoadTGA("mp_organic/organic_lf.tga");
	textSkyboxIzquierda.BuildGLTexture();
	textSkyboxIzquierda.ReleaseImage();

	textSkyboxDerecha.LoadTGA("mp_organic/organic_rt.tga");
	textSkyboxDerecha.BuildGLTexture();
	textSkyboxDerecha.ReleaseImage();

	textSkyboxArriba.LoadTGA("mp_organic/organic_up.tga");
	textSkyboxArriba.BuildGLTexture();
	textSkyboxArriba.ReleaseImage();

	textSkyboxAbajo.LoadTGA("mp_organic/organic_dn.tga");
	textSkyboxAbajo.BuildGLTexture();
	textSkyboxAbajo.ReleaseImage();


    textCasa.LoadTGA("tex/MadCasa.tga");
	textCasa.BuildGLTexture();
	textCasa.ReleaseImage();



	textPoste.LoadTGA("tex/MadPoste.tga");
	textPoste.BuildGLTexture();
	textPoste.ReleaseImage();

	textPiedra.LoadTGA("tex/piedra.tga");
	textPiedra.BuildGLTexture();
	textPiedra.ReleaseImage();

	textMueble1.LoadTGA("tex/mueble1.tga");
	textMueble1.BuildGLTexture();
	textMueble1.ReleaseImage();

	textMueble2.LoadTGA("tex/mueble2.tga");
	textMueble2.BuildGLTexture();
	textMueble2.ReleaseImage();
	   	 
	textEsca.LoadTGA("tex/Escalon.tga");
	textEsca.BuildGLTexture();
	textEsca.ReleaseImage();

	textOlmeca.LoadTGA("tex/olmeca.tga");
	textOlmeca.BuildGLTexture();
	textOlmeca.ReleaseImage();

	textTabli.LoadTGA("tex/tablillas.tga");
	textTabli.BuildGLTexture();
	textTabli.ReleaseImage();

	textDor.LoadTGA("tex/dorado.tga");
	textDor.BuildGLTexture();
	textDor.ReleaseImage();

	textLam.LoadTGA("tex/lamina.tga");
	textLam.BuildGLTexture();
	textLam.ReleaseImage();

	textPuerta1.LoadTGA("tex/puerta.tga");
	textPuerta1.BuildGLTexture();
	textPuerta1.ReleaseImage();
	
	textPuerta2.LoadTGA("tex/metal.tga");
	textPuerta2.BuildGLTexture();
	textPuerta2.ReleaseImage();

	textVen.LoadTGA("tex/ventana3.tga");
	textVen.BuildGLTexture();
	textVen.ReleaseImage();

	textInter.LoadTGA("tex/helado.tga");
	textInter.BuildGLTexture();
	textInter.ReleaseImage();

	textOso.LoadTGA("tex/oso.tga");
	textOso.BuildGLTexture();
	textOso.ReleaseImage();

	textLib1.LoadTGA("tex/libros.tga");
	textLib1.BuildGLTexture();
	textLib1.ReleaseImage();

	textCartel.LoadTGA("tex/Cartel.tga");
	textCartel.BuildGLTexture();
	textCartel.ReleaseImage();

	textLib2.LoadTGA("tex/libros2.tga");
	textLib2.BuildGLTexture();
	textLib2.ReleaseImage();

	textLet.LoadTGA("tex/letrero1.tga");
	textLet.BuildGLTexture();
	textLet.ReleaseImage();

	textTronco.LoadTGA("tex/tronco2.tga");
	textTronco.BuildGLTexture();
	textTronco.ReleaseImage();
	//END NEW//////////////////////////////

	objCamera.Position_Camera(6,6,6, 0,2.5f,0, 0, 1, 0);

	//NEW Crear una lista de dibujo
	Gravity_display_list = createDL();

}

void pintaTexto(float x, float y, float z, void *font,char *string)
{
  
  char *c;     //Almacena los caracteres a escribir
  glRasterPos3f(x, y, z);	//Posicion apartir del centro de la ventana
  //glWindowPos2i(150,100);
  for (c=string; *c != '\0'; c++) //Condicion de fin de cadena
  {
    glutBitmapCharacter(font, *c); //imprime
  }
}

void display ( void )   // Creamos la funcion donde se dibuja
{
	glClear (GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
	
	glLoadIdentity();
	
		
	glPushMatrix();
		glRotatef(g_lookupdown,1.0f,0,0);

		gluLookAt(	objCamera.mPos.x,  objCamera.mPos.y,  objCamera.mPos.z,	
					objCamera.mView.x, objCamera.mView.y, objCamera.mView.z,	
					objCamera.mUp.x,   objCamera.mUp.y,   objCamera.mUp.z);
	

		glPushMatrix();		
			glPushMatrix(); //Creamos cielo
				glDisable(GL_LIGHTING);
				glTranslatef(0,60,0);
				fig1.skybox(130.0, 130.0, 130.0, textSkyboxFrontal.GLindex, textSkyboxAtras.GLindex, textSkyboxIzquierda.GLindex, textSkyboxDerecha.GLindex, textSkyboxArriba.GLindex, textSkyboxAbajo.GLindex);
				glEnable(GL_LIGHTING);
			glPopMatrix();

			glPushMatrix();
				glEnable ( GL_COLOR_MATERIAL );
					glColor3f(1, 1, 1);
					glCallList(Gravity_display_list);
				glDisable ( GL_COLOR_MATERIAL );
			glPopMatrix();
			
		glPopMatrix(); 

		
	glPopMatrix();

glutSwapBuffers();


}

void animacion()
{



	glutPostRedisplay();
}

void reshape ( int width , int height )   // Creamos funcion Reshape
{
  if (height==0)										// Prevenir division entre cero
	{
		height=1;
	}

	glViewport(0,0,width,height);	

	glMatrixMode(GL_PROJECTION);						// Seleccionamos Projection Matrix
	glLoadIdentity();

	// Tipo de Vista
	
	glFrustum (-0.1, 0.1,-0.1, 0.1, 0.1, 170.0);

	glMatrixMode(GL_MODELVIEW);							// Seleccionamos Modelview Matrix
	glLoadIdentity();
}

void keyboard ( unsigned char key, int x, int y )  // Create Keyboard Function
{
	switch ( key ) {

		case 'w':   //Movimientos de camara
		case 'W':
			objCamera.Move_Camera( CAMERASPEED+0.2 );
			break;

		case 's':
		case 'S':
			objCamera.Move_Camera(-(CAMERASPEED+0.2));
			break;

		case 'a':
		case 'A':
			objCamera.Strafe_Camera(-(CAMERASPEED+0.3));
			break;

		case 'd':
		case 'D':
			objCamera.Strafe_Camera( CAMERASPEED+0.3 );
			break;

		case 27:        // Cuando Esc es presionado...
			exit ( 0 );   // Salimos del programa
			break;        
		default:        // Cualquier otra
			break;
  }

  glutPostRedisplay();
}

void arrow_keys ( int a_keys, int x, int y )  // Funcion para manejo de teclas especiales (arrow keys)
{
  switch ( a_keys ) {
	case GLUT_KEY_PAGE_UP:
		objCamera.UpDown_Camera(CAMERASPEED);
		break;

	case GLUT_KEY_PAGE_DOWN:
		objCamera.UpDown_Camera(-CAMERASPEED);
		break;

    case GLUT_KEY_UP:     // Presionamos tecla ARRIBA...
		g_lookupdown -= 1.0f;
		break;

    case GLUT_KEY_DOWN:               // Presionamos tecla ABAJO...
		g_lookupdown += 1.0f;
		break;

	case GLUT_KEY_LEFT:
		objCamera.Rotate_View(-CAMERASPEED);
		break;

	case GLUT_KEY_RIGHT:
		objCamera.Rotate_View( CAMERASPEED);
		break;

		//teclas para c�mara
	case GLUT_KEY_F1:
		//c�mara 1
		objCamera.Position_Camera(5, 15, 10, 0, 2.5f, 0, 0, 1, 0);
		break;

	case GLUT_KEY_F2:
		//c�mara 2
		objCamera.Position_Camera(0, 30, 60, 0, 2.5f, 0, 0, 1, 0);
		break;

	case GLUT_KEY_F3:
		//c�mara 3
		objCamera.Position_Camera(60, 30, 0, 20, 2.5f, 0, 0, 1, 0);
		break;

	case GLUT_KEY_F4:
		//c�mara 4
		objCamera.Position_Camera(-50, 60, -50, 20, 2.5f, 0, 0, 1, 0);
		break;

	case GLUT_KEY_F5:
		//c�mara 5
		objCamera.Position_Camera(-50, 60, 50, 25, 2.5, 0, 0, 1, 0);
		break;

	case GLUT_KEY_F6:
		//Camara inicial
		objCamera.Position_Camera(50, 40, 50, 0, 2.5f, 0, 0, 1, 0);

	default:
		break;
  }
  glutPostRedisplay();
}

int main ( int argc, char** argv )   // Main Function
{

  glutInit            (&argc, argv); // Inicializamos OpenGL
  glutInitDisplayMode (GLUT_RGB | GLUT_DOUBLE | GLUT_DEPTH); // Display Mode (Clores RGB y alpha | Buffer Doble )
  glutInitWindowSize  (500, 500);	// Tama�o de la Ventana
  glutInitWindowPosition (0, 0);	//Posicion de la Ventana
  glutCreateWindow    ("Final"); // Nombre de la Ventana
  //glutFullScreen     ( );         // Full Screen
  InitGL ();						// Parametros iniciales de la aplicacion
  glutDisplayFunc     ( display );  //Indicamos a Glut funci�n de dibujo
  glutReshapeFunc     ( reshape );	//Indicamos a Glut funci�n en caso de cambio de tamano
  glutKeyboardFunc    ( keyboard );	//Indicamos a Glut funci�n de manejo de teclado
  glutSpecialFunc     ( arrow_keys );	//Otras
  glutIdleFunc		  ( animacion );


  glutMainLoop        ( );          // 

  return 0;
}
